function preload() {

    myFont = loadFont('Sans.ttf'); 
    myFontBi = loadFont('LatoBI.ttf')
}

function setup() {
  // put setup code here
    createCanvas(windowWidth, windowHeight);

    textAlign(CENTER);
    noLoop();
    
    textSize(32);
    
    textFont(myFont);
    
    background('pink')
}

function draw() {
  // put drawing code here
    textSize(32)
    textFont(myFontBi)
    text('Harrisburg University', 700, 60);
    
    textFont(myFont)
    textSize(14)
    text('Hello, I am Daniel Farley from Harirsburg University. I am an IMED student with a focus in purposeful game design. I am currently living on campus doing online courses, including IMED 120.', 700, 180);
}